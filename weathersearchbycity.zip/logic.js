const apikey="ad5fb7fefad5b32c0a290e3927914dca";  //ad5fb7fefad5b32c0a290e3927914dca

const apiUrl="https://api.openweathermap.org/data/2.5/weather?&units=metric&q=";

const searchBOX=document.querySelector(".searchBox input");
const searchBtn=document.querySelector(".searchBox button");
const weatherIcon=document.querySelector(".weather-icon");

async function Checkweather(city) {
    const response = await fetch(apiUrl+ city+ `&appid=${apikey}`);
    if (response.status == 404){
        document.querySelector(".error").style.display="block";
        document.querySelector(".Weather ").style.display="none";
    }
    else{
        var data = await response.json();
        console.log(data);
        document.querySelector(".city").innerHTML=data.name;
        document.querySelector(".temp").innerHTML=Math.round(data.main.temp)+"°C";
        document.querySelector(".humidity").innerHTML=data.main.humidity +"%";
        document.querySelector(".wind").innerHTML=data.wind.speed + "km/hr";
    
    
        if (data.weather[0].main=="Clouds"){
            weatherIcon.src="/img/cloud1.webp";
    
        }
        else if(data.weather[0].main=="Clear"){
            weatherIcon.src="/img/clear.png";
        }
        else if(data.weather[0].main=="Rain"){
            weatherIcon.src="/img/rain.jpg";
        }
    
        else if(data.weather[0].main=="Clear"){
            weatherIcon.src="/img/clear.png";
        }
    
        document.querySelector(".Weather").style.display="block";
        document.querySelector(".error").style.display="none";
    
    

    }

}

searchBtn.addEventListener("click",()=>{
    Checkweather(searchBOX.value);



})


